package March16.org;

import java.util.Scanner;

public class firstReplaceApp
{

	public static void main(String[] args) 
	{
		 System.out.println("Enter String");
		  String str;
		  char rep;
		  Scanner xyz=new Scanner(System.in);
		  str=xyz.nextLine();
		  StringBuffer sb=new StringBuffer(str);
		  int len=sb.length();
		  System.out.println("len--->"+len);
		  System.out.println("Before Replace--->"+sb);
		  System.out.println("Enter character");
		  rep=xyz.next().charAt(0);
		  for(int i=0;i<len;i++)
		  {
           char a=sb.charAt(i);
           if(a!=' '|| a>=65 && a<=90 || a>=97 && a<=122)
           {
       	    sb.setCharAt(i,rep);
       	    break;
            }
		  }
		  System.out.println("After Replace--->"+sb);

		
	}

}
