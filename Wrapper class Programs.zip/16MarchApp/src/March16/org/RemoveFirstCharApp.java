package March16.org;

import java.util.Scanner;

public class RemoveFirstCharApp 
{

	public static void main(String[] args) 
	{
		 System.out.println("Enter String");
		  String str;
		  Scanner xyz=new Scanner(System.in);
		  str=xyz.nextLine();
		  StringBuffer sb=new StringBuffer(str);
		  int len=sb.length();
		  System.out.println("len--->"+len);
		  System.out.println("Before delete--->"+sb);
		  for(int i=0;i<len;i++)
		  {
           char a=sb.charAt(i);
          if(a!=' '|| a>=65 && a<=90 || a>=97 && a<=122)
          {
        	  sb=sb.deleteCharAt(i);
        	  break;
          }
		  }
 System.out.println("After delete-->"+sb);
	}

}
