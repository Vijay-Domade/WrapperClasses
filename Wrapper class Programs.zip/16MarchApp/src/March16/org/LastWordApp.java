package March16.org;

import java.util.Scanner;

public class LastWordApp 
{

	public static void main(String[] args)
	{
		 System.out.println("Enter String");
		  String str;
		  char l=' ';
		  Scanner xyz=new Scanner(System.in);
		  str=xyz.nextLine();
		  StringBuffer sb=new StringBuffer(str);
		  int len=sb.length();
		  System.out.println("len--->"+len);
for(int i=0;i<len;i++)
{
	int e=i;
	if(i==len-1)
	{
		while(i!=0)
		{
			char b=sb.charAt(i);
			if(b>=65 && b<=90 || b>=97 && b<=122)
			{
				l=sb.charAt(i);
				break;
			}
			i--;
		}
	}
	i=e;
	
}
System.out.println("Last word--->"+l);
	}

}
