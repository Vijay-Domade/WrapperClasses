package March16.org;

import java.util.Scanner;

public class Find1stApp
{

	public static void main(String[] args)
	{
		System.out.println("Enter String");
		  String str;
		  char f=' ';
		  Scanner xyz=new Scanner(System.in);
		  str=xyz.nextLine();
		  StringBuffer sb=new StringBuffer(str);
		  int len=sb.length();
		  System.out.println("len--->"+len);
		  for(int i=0;i<len;i++)
		  {
char a=sb.charAt(i);
        if(a!=' '|| a>=65 && a<=90 || a>=97 && a<=122)
        {
      	  f=sb.charAt(i);
      	  break;
        }
	 }
System.out.println("First word-->"+f);
	}

}
