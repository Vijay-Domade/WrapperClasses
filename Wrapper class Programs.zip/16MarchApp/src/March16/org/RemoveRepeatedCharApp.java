package March16.org;

import java.util.Scanner;

public class RemoveRepeatedCharApp 
{

	public static void main(String[] args) 
	{
		System.out.println("Enter String");
		  String str;
		  Scanner xyz=new Scanner(System.in);
		  str=xyz.nextLine();
		  StringBuffer sb=new StringBuffer(str);
		  int len=sb.length();
		  System.out.println("len--->"+len);
		  System.out.println("Before delete--->"+sb);
		  for(int i=0;i<len;i++)
		  {
			 for(int j=i+1;j<len;j++)
			 {
				 char a=sb.charAt(i);
				 char b=sb.charAt(j);
				if(a==b)
				{	
				  sb=sb.deleteCharAt(j);
				  j=j-1;
				  len--;
				}
			 }
				 
		  }
		  System.out.println("After delete--->"+sb);


	}

}
