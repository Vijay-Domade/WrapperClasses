package March16.org;

import java.util.Scanner;
import java.util.*;

public class LastReplaceApp 
{

	public static void main(String[] args) 
	{
		System.out.println("Enter String");
		  String str;
		  Scanner xyz=new Scanner(System.in);
		  str=xyz.nextLine();
		  StringBuffer sb=new StringBuffer(str);
		  int len=sb.length();
		  System.out.println("len--->"+len);
		  System.out.println("Before Replace--->"+sb);
		  char rep='w';
		  for(int i=0;i<len;i++)
		  {
		  	int e=i;
		  	if(i==len-1)
		  	{
		  		while(i!=0)
		  		{
		  			char b=sb.charAt(i);
		  			if(b>=65 && b<=90 || b>=97 && b<=122)
		  			{
		  				sb.setCharAt(i, rep);
		  				break;
		  			}
		  			i--;
		  		}
		  	}
		  	i=e;
		  	
		  }
		  System.out.println("After Replace--->"+sb);

	}
	

}
